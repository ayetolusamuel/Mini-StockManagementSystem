 /*Table structure for table `productnamecat`*/
--

CREATE TABLE `stock` (
  `pcode` varchar(7) NOT NULL,
  `price` varchar(10) NOT NULL,
  `productname` varchar(250) NOT NULL,
  `productcat` varchar(450) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productnamecat`
--

INSERT INTO `stock` (`pcode`, `price`, `productname`, `productcat`) VALUES
('Set0001', '2,600', 'HDMI to VGA Converter -White', 'Office Tools');
