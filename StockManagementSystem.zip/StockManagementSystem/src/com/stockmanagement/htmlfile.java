package com.stockmanagement;

import javax.swing.*;

public class htmlfile extends JInternalFrame{

	
	
	
	public htmlfile(String title,String filename){
		//supertittle,Resizable,maximizable,iconifiable()
		super(title,false,true,true,true);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setSize(440,323);
		//setSize(440,343);
		HtmlPane html=new HtmlPane(filename);
		setContentPane(html);
		setVisible(true);
		
		
	}
}
