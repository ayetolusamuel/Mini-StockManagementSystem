To see how this programme work, open the stockmanagement file, and use the information there in your app by click add new product and cat. and input the information found in the file.
please make sure you set the path of the image(s).
To see how its work.....input Set0001 in the pcode field.
Mind you dont forget to on your Xapp to be able to use your database.
check your stockmanagement.sql file for the Query.
thanks for downloading my source code.
Contact me on:
Ayetolusamuel@gmail.com
fb id:facebook.com/ayetolusamuelsetonji
num:+2348167137007